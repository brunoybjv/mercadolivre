# Mercado-livre clone
 Projeto educativo replicando visual e funcionalidades do Mercado Livre para aprimorar habilidades de desenvolvimento web.
